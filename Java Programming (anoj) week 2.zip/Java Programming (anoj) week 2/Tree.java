public class Tree {
    public static void main(String[]args){
        String a= "   /\\' \n  /  \\'\n /    \\' \n/      \\'";
        String b ="\n-------- \n";
        String c ="  \"  \"\n  \"  \"\n  \"  \"";
        System.out.println(a+b+c);
    }

}
