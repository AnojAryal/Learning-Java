public class Hello {
    public static void main(String[]args){
        final String h = "*   *\n*   *\n*****\n*   *\n*   *";
        final String e = "\n\n*****\n*\n*\n*****\n*\n*\n*****";
        final String l = " \n\n*\n*\n*\n*\n*****";
        final String o = "\n\n*****\n*   *\n*   *\n*   *\n*****";

        System.out.print(h + e + l + l + o );
    }

}
