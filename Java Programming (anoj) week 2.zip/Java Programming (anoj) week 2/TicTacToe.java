public class TicTacToe {
    public static  String comb = "+--+--+--+\n|  |  |  |";
    public static  String line = "+--+--+--+";
    public static void main(String[] args) {
        System.out.println(comb);
        System.out.println(comb);
        System.out.println(comb);
        System.out.println(line);
        

    }
}
